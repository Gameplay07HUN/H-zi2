﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Helsinki2017
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. feladat:");
            var cucc = "rovidprogram.csv";
            var cucc2 = "donto.csv";
            string[] rövid = File.ReadAllLines(cucc, Encoding.UTF8).Skip(1).ToArray();
            var lista = new List<RovidProgram>();
            foreach (string one in rövid)
            {
                string[] split = one.Split(';');

                lista.Add(new RovidProgram(split[0], split[1],
                    double.Parse(split[2].Replace('.', ',')),
                    double.Parse(split[3].Replace('.', ',')), int.Parse(split[4])));
            }
            string[] donto = File.ReadAllLines(cucc2, Encoding.UTF8);
            var lista2 = new List<RovidProgram>();
            foreach (string one in donto)
            {
                string[] split = one.Split(';');

                lista.Add(new RovidProgram(split[0], split[1],
                    double.Parse(split[2].Replace('.', ',')),
                    double.Parse(split[3].Replace('.', ',')), int.Parse(split[4])));
            }
            Console.WriteLine("2. feladat");
            Console.WriteLine(rövid.Length);
            Console.WriteLine("3. feladat");
            foreach (RovidProgram rp in lista)
            {
                if (rp.Orszag.Equals("HUN"))
                {
                    Console.WriteLine(rp.Nev);
                }
            }
            Console.WriteLine("4. feladat");

            Console.ReadKey();
        }
        public void ÖsszPontszám()
        {
            RovidProgram vers = RovidProgram.Find(rp => rp.Nev.Equals(nev));

            if (vers == null)
            {
                return 0;
            }

            lista2 dontos = donto.Find(ds => ds.Nev.Equals(nev));

            return dontos == null ? vers.Technikai : dontos.Technikai + vers.Technikai;
        }
        public class RovidProgram
        {

            public string Nev { get; private set; }
            public string Orszag { get; private set; }

            public double Technikai { get; private set; }
            public double Komponens { get; private set; }

            public int Levonas { get; private set; }

            public RovidProgram(string Nev, string Orszag, double Technikai, double Komponens, int Levonas)
            {
                this.Nev = Nev;
                this.Orszag = Orszag;
                this.Technikai = Technikai;
                this.Komponens = Komponens;
                this.Levonas = Levonas;
            }
        }
    }
}
